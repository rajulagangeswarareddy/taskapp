'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { api } from '@/lib/apiClient'
import TaskModal from '@/components/TaskModal'

interface Task {
  _id: string
  title: string
  description: string
  status: 'pending' | 'in-progress' | 'completed'
  createdAt: string
}

interface Pagination {
  total: number
  page: number
  limit: number
  totalPages: number
  hasNext: boolean
  hasPrev: boolean
}

interface User {
  name: string
  email: string
}

const STATUS_LABELS: Record<Task['status'], string> = {
  pending: 'Pending',
  'in-progress': 'In Progress',
  completed: 'Completed',
}

const STATUS_DOT: Record<Task['status'], string> = {
  pending: '●',
  'in-progress': '◉',
  completed: '✓',
}

function formatDate(d: string) {
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

export default function TasksPage() {
  const router = useRouter()
  const [tasks, setTasks] = useState<Task[]>([])
  const [pagination, setPagination] = useState<Pagination | null>(null)
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<User | null>(null)

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [page, setPage] = useState(1)

  const [showModal, setShowModal] = useState(false)
  const [editTask, setEditTask] = useState<Task | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const searchTimer = useRef<ReturnType<typeof setTimeout>>(undefined)

  const fetchTasks = useCallback(async (s: string, status: string, p: number) => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(p), limit: '10' })
      if (s) params.set('search', s)
      if (status) params.set('status', status)
      const res = await api.get<{ tasks: Task[]; pagination: Pagination }>(`/api/tasks?${params}`)
      setTasks((res as unknown as { tasks: Task[] }).tasks || [])
      setPagination((res as unknown as { pagination: Pagination }).pagination || null)
    } catch {
      setTasks([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    // Get user from cookie/session check
    fetch('/api/auth/me').then(r => r.json()).then(j => {
      if (j?.data) {
        try {
          const parsed = JSON.parse(atob(j.data.split(':')[2] || '') || '{}')
          void parsed
        } catch { /* ignore */ }
      }
    }).catch(() => {})
  }, [])

  useEffect(() => {
    fetchTasks(search, statusFilter, page)
  }, [statusFilter, page, fetchTasks])

  const handleSearchChange = (val: string) => {
    setSearch(val)
    clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(() => {
      setPage(1)
      fetchTasks(val, statusFilter, 1)
    }, 400)
  }

  const handleFilterChange = (val: string) => {
    setStatusFilter(val)
    setPage(1)
  }

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/login')
    router.refresh()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this task?')) return
    setDeletingId(id)
    try {
      await api.delete(`/api/tasks/${id}`)
      fetchTasks(search, statusFilter, page)
    } catch (err) {
      alert((err as Error).message)
    } finally {
      setDeletingId(null)
    }
  }

  const handleSaved = () => {
    setShowModal(false)
    setEditTask(null)
    fetchTasks(search, statusFilter, page)
  }

  const openEdit = (task: Task) => {
    setEditTask(task)
    setShowModal(true)
  }

  const stats = {
    total: pagination?.total ?? tasks.length,
    pending: tasks.filter(t => t.status === 'pending').length,
    inProgress: tasks.filter(t => t.status === 'in-progress').length,
    completed: tasks.filter(t => t.status === 'completed').length,
  }

  return (
    <div className="dashboard">
      <header className="header">
        <div className="header-logo">TaskFlow</div>
        <div className="header-right">
          {user && <span className="header-user">{user.name}</span>}
          <button className="btn btn-ghost btn-sm" onClick={handleLogout}>
            Sign out
          </button>
        </div>
      </header>

      <main className="main">
        {/* Toolbar */}
        <div className="toolbar">
          <div className="search-wrap">
            <span className="search-icon">⌕</span>
            <input
              type="text"
              className="search-input"
              placeholder="Search tasks…"
              value={search}
              onChange={(e) => handleSearchChange(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={statusFilter}
            onChange={(e) => handleFilterChange(e.target.value)}
          >
            <option value="">All statuses</option>
            <option value="pending">Pending</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>

          <button
            className="btn btn-primary btn-sm"
            onClick={() => { setEditTask(null); setShowModal(true) }}
          >
            + New task
          </button>
        </div>

        {/* Stats */}
        <div className="stats-bar">
          <div className="stat-chip">
            <span className="stat-num">{pagination?.total ?? '—'}</span> total
          </div>
          <div className="stat-chip">
            <span style={{ color: 'var(--amber)' }}>●</span>
            <span className="stat-num">{stats.pending}</span> pending
          </div>
          <div className="stat-chip">
            <span style={{ color: 'var(--blue)' }}>◉</span>
            <span className="stat-num">{stats.inProgress}</span> in progress
          </div>
          <div className="stat-chip">
            <span style={{ color: 'var(--green)' }}>✓</span>
            <span className="stat-num">{stats.completed}</span> done
          </div>
        </div>

        {/* Section header */}
        <div className="section-header">
          <span className="section-title">
            {statusFilter ? STATUS_LABELS[statusFilter as Task['status']] : 'All tasks'}
            {search ? ` · "${search}"` : ''}
          </span>
        </div>

        {/* Task list */}
        {loading ? (
          <div>
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="skeleton skeleton-card" />
            ))}
          </div>
        ) : tasks.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">◫</div>
            <div className="empty-title">
              {search || statusFilter ? 'No tasks match your filters' : 'No tasks yet'}
            </div>
            <p style={{ fontSize: 13, marginTop: 8 }}>
              {search || statusFilter
                ? 'Try adjusting your search or filter'
                : 'Create your first task to get started'}
            </p>
            {!search && !statusFilter && (
              <button
                className="btn btn-primary"
                style={{ marginTop: 20 }}
                onClick={() => { setEditTask(null); setShowModal(true) }}
              >
                + New task
              </button>
            )}
          </div>
        ) : (
          <div className="task-list">
            {tasks.map((task) => (
              <div key={task._id} className={`task-card status-${task.status}`}>
                <div className="task-body">
                  <div className={`task-title ${task.status === 'completed' ? 'done' : ''}`}>
                    {task.title}
                  </div>
                  {task.description && (
                    <div className="task-desc">{task.description}</div>
                  )}
                  <div className="task-meta">
                    <span className={`status-badge badge-${task.status}`}>
                      {STATUS_DOT[task.status]} {STATUS_LABELS[task.status]}
                    </span>
                    <span className="task-date">{formatDate(task.createdAt)}</span>
                  </div>
                </div>

                <div className="task-actions">
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => openEdit(task)}
                    title="Edit"
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(task._id)}
                    disabled={deletingId === task._id}
                    title="Delete"
                  >
                    {deletingId === task._id ? <span className="spinner" /> : 'Del'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {pagination && pagination.totalPages > 1 && (
          <div className="pagination">
            <button
              className="btn btn-ghost btn-sm"
              disabled={!pagination.hasPrev}
              onClick={() => setPage((p) => p - 1)}
            >
              ← Prev
            </button>
            <span className="page-info">
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <button
              className="btn btn-ghost btn-sm"
              disabled={!pagination.hasNext}
              onClick={() => setPage((p) => p + 1)}
            >
              Next →
            </button>
          </div>
        )}
      </main>

      {/* Modal */}
      {showModal && (
        <TaskModal
          task={editTask}
          onClose={() => { setShowModal(false); setEditTask(null) }}
          onSaved={handleSaved}
        />
      )}
    </div>
  )
}
