import { NextRequest } from 'next/server'
import { z } from 'zod'
import { connectDB } from '@/lib/db'
import { User } from '@/models/User'
import { signToken } from '@/lib/jwt'
import { successResponse, errorResponse } from '@/lib/response'
import { decryptPayload } from '@/lib/crypto'

const LoginSchema = z.object({
  email: z.string().email().toLowerCase(),
  password: z.string().min(1),
})

export async function POST(req: NextRequest) {
  try {
    await connectDB()

    const body = await req.json()

    let input: z.infer<typeof LoginSchema>
    try {
      const decrypted = decryptPayload<z.infer<typeof LoginSchema>>(body)
      input = LoginSchema.parse(decrypted)
    } catch {
      input = LoginSchema.parse(body)
    }

    const user = await User.findOne({ email: input.email }).select('+password')
    if (!user) return errorResponse('Invalid credentials', 401)

    const valid = await user.comparePassword(input.password)
    if (!valid) return errorResponse('Invalid credentials', 401)

    const token = signToken({ userId: user._id.toString(), email: user.email })

    const res = successResponse({
      user: { id: user._id, name: user.name, email: user.email },
    })

    res.cookies.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7,
      path: '/',
    })

    return res
  } catch (err) {
    if (err instanceof z.ZodError) {
      return errorResponse(err.errors[0].message, 422)
    }
    console.error('Login error:', err)
    return errorResponse('Internal server error', 500)
  }
}
