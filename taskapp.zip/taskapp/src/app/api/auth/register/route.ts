import { NextRequest } from 'next/server'
import { z } from 'zod'
import { connectDB } from '@/lib/db'
import { User } from '@/models/User'
import { signToken } from '@/lib/jwt'
import { successResponse, errorResponse } from '@/lib/response'
import { decryptPayload } from '@/lib/crypto'

const RegisterSchema = z.object({
  name: z.string().min(2).max(100).trim(),
  email: z.string().email().toLowerCase(),
  password: z.string().min(6).max(100),
})

export async function POST(req: NextRequest) {
  try {
    await connectDB()

    const body = await req.json()

    // Decrypt incoming payload
    let input: z.infer<typeof RegisterSchema>
    try {
      const decrypted = decryptPayload<z.infer<typeof RegisterSchema>>(body)
      input = RegisterSchema.parse(decrypted)
    } catch {
      // Support plain JSON for backward compat during dev
      input = RegisterSchema.parse(body)
    }

    const existing = await User.findOne({ email: input.email })
    if (existing) return errorResponse('Email already in use', 409)

    const user = await User.create(input)
    const token = signToken({ userId: user._id.toString(), email: user.email })

    const res = successResponse(
      { user: { id: user._id, name: user.name, email: user.email } },
      201
    )

    res.cookies.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: '/',
    })

    return res
  } catch (err) {
    if (err instanceof z.ZodError) {
      return errorResponse(err.errors[0].message, 422)
    }
    console.error('Register error:', err)
    return errorResponse('Internal server error', 500)
  }
}
