import { NextRequest } from 'next/server'
import { getAuthUser } from '@/middleware/auth'
import { connectDB } from '@/lib/db'
import { User } from '@/models/User'
import { successResponse, errorResponse } from '@/lib/response'

export async function GET(req: NextRequest) {
  try {
    const auth = getAuthUser(req)
    if (!auth) return errorResponse('Unauthorized', 401)

    await connectDB()
    const user = await User.findById(auth.userId).lean()
    if (!user) return errorResponse('User not found', 404)

    return successResponse({ user })
  } catch {
    return errorResponse('Internal server error', 500)
  }
}
