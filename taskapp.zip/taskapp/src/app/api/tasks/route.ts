import { NextRequest } from 'next/server'
import { z } from 'zod'
import { connectDB } from '@/lib/db'
import { Task } from '@/models/Task'
import { requireAuth } from '@/middleware/auth'
import { successResponse, errorResponse } from '@/lib/response'
import { decryptPayload } from '@/lib/crypto'

const CreateTaskSchema = z.object({
  title: z.string().min(1).max(200).trim(),
  description: z.string().max(2000).trim().default(''),
  status: z.enum(['pending', 'in-progress', 'completed']).default('pending'),
})

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const user = requireAuth(req)

    const { searchParams } = req.nextUrl
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1'))
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') ?? '10')))
    const status = searchParams.get('status')
    const search = searchParams.get('search')?.trim()

    // Build query - always scope to user's tasks
    const query: Record<string, unknown> = { userId: user.userId }

    if (status && ['pending', 'in-progress', 'completed'].includes(status)) {
      query.status = status
    }

    if (search) {
      // Case-insensitive title search, escape special regex chars
      const escaped = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      query.title = { $regex: escaped, $options: 'i' }
    }

    const [tasks, total] = await Promise.all([
      Task.find(query)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Task.countDocuments(query),
    ])

    return successResponse({
      tasks,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrev: page > 1,
      },
    })
  } catch (err) {
    if ((err as Error).message === 'UNAUTHORIZED') return errorResponse('Unauthorized', 401)
    console.error('GET tasks error:', err)
    return errorResponse('Internal server error', 500)
  }
}

export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const user = requireAuth(req)

    const body = await req.json()

    let input: z.infer<typeof CreateTaskSchema>
    try {
      const decrypted = decryptPayload<z.infer<typeof CreateTaskSchema>>(body)
      input = CreateTaskSchema.parse(decrypted)
    } catch {
      input = CreateTaskSchema.parse(body)
    }

    const task = await Task.create({ ...input, userId: user.userId })

    return successResponse({ task }, 201)
  } catch (err) {
    if ((err as Error).message === 'UNAUTHORIZED') return errorResponse('Unauthorized', 401)
    if (err instanceof z.ZodError) return errorResponse(err.errors[0].message, 422)
    console.error('POST task error:', err)
    return errorResponse('Internal server error', 500)
  }
}
