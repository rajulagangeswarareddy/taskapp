import { NextRequest } from 'next/server'
import { z } from 'zod'
import { connectDB } from '@/lib/db'
import { Task } from '@/models/Task'
import { requireAuth } from '@/middleware/auth'
import { successResponse, errorResponse } from '@/lib/response'
import { decryptPayload } from '@/lib/crypto'

const UpdateTaskSchema = z.object({
  title: z.string().min(1).max(200).trim().optional(),
  description: z.string().max(2000).trim().optional(),
  status: z.enum(['pending', 'in-progress', 'completed']).optional(),
})

type Params = { params: { id: string } }

export async function GET(req: NextRequest, { params }: Params) {
  try {
    await connectDB()
    const user = requireAuth(req)

    const task = await Task.findOne({ _id: params.id, userId: user.userId })
    if (!task) return errorResponse('Task not found', 404)

    return successResponse({ task })
  } catch (err) {
    if ((err as Error).message === 'UNAUTHORIZED') return errorResponse('Unauthorized', 401)
    return errorResponse('Internal server error', 500)
  }
}

export async function PUT(req: NextRequest, { params }: Params) {
  try {
    await connectDB()
    const user = requireAuth(req)

    const body = await req.json()

    let input: z.infer<typeof UpdateTaskSchema>
    try {
      const decrypted = decryptPayload<z.infer<typeof UpdateTaskSchema>>(body)
      input = UpdateTaskSchema.parse(decrypted)
    } catch {
      input = UpdateTaskSchema.parse(body)
    }

    // Authorization: userId must match
    const task = await Task.findOneAndUpdate(
      { _id: params.id, userId: user.userId },
      { $set: input },
      { new: true, runValidators: true }
    )

    if (!task) return errorResponse('Task not found', 404)

    return successResponse({ task })
  } catch (err) {
    if ((err as Error).message === 'UNAUTHORIZED') return errorResponse('Unauthorized', 401)
    if (err instanceof z.ZodError) return errorResponse(err.errors[0].message, 422)
    return errorResponse('Internal server error', 500)
  }
}

export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    await connectDB()
    const user = requireAuth(req)

    const task = await Task.findOneAndDelete({ _id: params.id, userId: user.userId })
    if (!task) return errorResponse('Task not found', 404)

    return successResponse({ message: 'Task deleted' })
  } catch (err) {
    if ((err as Error).message === 'UNAUTHORIZED') return errorResponse('Unauthorized', 401)
    return errorResponse('Internal server error', 500)
  }
}
