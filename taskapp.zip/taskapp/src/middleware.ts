import { NextRequest, NextResponse } from 'next/server'
import { verifyToken } from '@/lib/jwt'

const PUBLIC_PATHS = ['/login', '/register', '/api/auth/login', '/api/auth/register']

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl

  // Allow public paths
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next()
  }

  // Allow static files
  if (pathname.startsWith('/_next') || pathname.includes('.')) {
    return NextResponse.next()
  }

  const token = req.cookies.get('auth_token')?.value

  // Protect pages
  if (!pathname.startsWith('/api/')) {
    if (!token) return NextResponse.redirect(new URL('/login', req.url))
    try {
      verifyToken(token)
    } catch {
      const res = NextResponse.redirect(new URL('/login', req.url))
      res.cookies.delete('auth_token')
      return res
    }
  }

  // Protect API routes
  if (pathname.startsWith('/api/') && !PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    if (!token) {
      return NextResponse.json({ data: '' }, { status: 401 })
    }
    try {
      verifyToken(token)
    } catch {
      return NextResponse.json({ data: '' }, { status: 401 })
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
