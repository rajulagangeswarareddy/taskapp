'use client'

// Client-side AES-256-GCM using Web Crypto API
async function getKey(): Promise<CryptoKey> {
  const secret = process.env.NEXT_PUBLIC_AES_SECRET_KEY || ''
  const encoder = new TextEncoder()
  const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(secret), 'PBKDF2', false, ['deriveKey'])
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: encoder.encode('taskapp-salt'), iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  )
}

async function encryptData(data: unknown): Promise<{ data: string }> {
  const key = await getKey()
  const iv = crypto.getRandomValues(new Uint8Array(16))
  const encoded = new TextEncoder().encode(JSON.stringify(data))
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded)
  const combined = new Uint8Array(iv.byteLength + encrypted.byteLength)
  combined.set(iv, 0)
  combined.set(new Uint8Array(encrypted), iv.byteLength)
  return { data: btoa(String.fromCharCode(...combined)) }
}

async function decryptData<T>(encryptedObj: { data: string }): Promise<T> {
  if (!encryptedObj?.data) return encryptedObj as T
  try {
    const key = await getKey()
    const combined = Uint8Array.from(atob(encryptedObj.data), (c) => c.charCodeAt(0))
    const iv = combined.slice(0, 16)
    const encrypted = combined.slice(16)
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, encrypted)
    return JSON.parse(new TextDecoder().decode(decrypted)) as T
  } catch {
    return encryptedObj as unknown as T
  }
}

interface ApiResponse<T = unknown> {
  success: boolean
  error?: string
  [key: string]: unknown
  _data?: T
}

async function request<T = unknown>(
  url: string,
  options: RequestInit & { body?: unknown } = {}
): Promise<ApiResponse<T> & T> {
  const { body, ...rest } = options

  const fetchOptions: RequestInit = { ...rest, credentials: 'include' }

  if (body !== undefined) {
    const encrypted = await encryptData(body)
    fetchOptions.body = JSON.stringify(encrypted)
    fetchOptions.headers = { 'Content-Type': 'application/json', ...(rest.headers || {}) }
  }

  const res = await fetch(url, fetchOptions)
  const json = await res.json()

  const decrypted = await decryptData<ApiResponse<T>>(json)

  if (!res.ok) {
    throw new Error((decrypted as { error?: string }).error || `Request failed: ${res.status}`)
  }

  return decrypted as ApiResponse<T> & T
}

export const api = {
  post: <T = unknown>(url: string, body: unknown) =>
    request<T>(url, { method: 'POST', body }),

  put: <T = unknown>(url: string, body: unknown) =>
    request<T>(url, { method: 'PUT', body }),

  get: <T = unknown>(url: string) =>
    request<T>(url, { method: 'GET' }),

  delete: <T = unknown>(url: string) =>
    request<T>(url, { method: 'DELETE' }),
}
