import { NextResponse } from 'next/server'
import { encryptPayload } from './crypto'

export function successResponse(data: unknown, status = 200) {
  const encrypted = encryptPayload({ success: true, ...( typeof data === 'object' && data !== null ? data : { data }) })
  return NextResponse.json(encrypted, { status })
}

export function errorResponse(message: string, status = 400) {
  const encrypted = encryptPayload({ success: false, error: message })
  return NextResponse.json(encrypted, { status })
}
