import mongoose, { Document, Schema, Types } from 'mongoose'

export type TaskStatus = 'pending' | 'in-progress' | 'completed'

export interface ITask extends Document {
  title: string
  description: string
  status: TaskStatus
  userId: Types.ObjectId
  createdAt: Date
  updatedAt: Date
}

const TaskSchema = new Schema<ITask>(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [200, 'Title too long'],
    },
    description: {
      type: String,
      trim: true,
      maxlength: [2000, 'Description too long'],
      default: '',
    },
    status: {
      type: String,
      enum: ['pending', 'in-progress', 'completed'],
      default: 'pending',
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
  },
  { timestamps: true }
)

// Compound index for efficient user + status queries
TaskSchema.index({ userId: 1, status: 1 })
TaskSchema.index({ userId: 1, createdAt: -1 })
TaskSchema.index({ userId: 1, title: 'text' })

TaskSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.__v
    return ret
  },
})

export const Task = mongoose.models.Task || mongoose.model<ITask>('Task', TaskSchema)
