import { NextRequest } from 'next/server'
import { verifyToken, JWTPayload } from '@/lib/jwt'

export function getAuthUser(req: NextRequest): JWTPayload | null {
  try {
    const token = req.cookies.get('auth_token')?.value
    if (!token) return null
    return verifyToken(token)
  } catch {
    return null
  }
}

export function requireAuth(req: NextRequest): JWTPayload {
  const user = getAuthUser(req)
  if (!user) throw new Error('UNAUTHORIZED')
  return user
}
