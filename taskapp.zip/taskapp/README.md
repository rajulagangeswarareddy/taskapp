# TaskFlow — Full Stack Task Management App

A production-ready Task Management Application built with Next.js 14, MongoDB, JWT authentication, and AES-256-GCM end-to-end encryption.

**Live URL:** `https://your-app.vercel.app`  
**GitHub:** `https://github.com/your-username/taskapp`

---

## Features

- **JWT Authentication** — stored in HTTP-only, Secure, SameSite=Strict cookies
- **AES-256-GCM E2E Encryption** — every request and response payload is encrypted
- **bcrypt password hashing** — salt rounds of 12
- **CRUD task management** — create, read, update, delete tasks
- **Pagination** — 10 tasks per page with total/page metadata
- **Filter by status** — pending / in-progress / completed
- **Search by title** — debounced, case-insensitive regex search
- **Authorization** — users can only access their own tasks (userId scoped on every query)
- **Input validation** — Zod schemas on all endpoints
- **Protected frontend routes** — Next.js middleware redirects unauthenticated users
- **Clean dark UI** — industrial theme with DM Mono + Syne fonts

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  Next.js 14 (App Router)                            │
│                                                     │
│  ┌─────────────┐    ┌──────────────────────────┐   │
│  │  Frontend   │    │     API Routes           │   │
│  │  /login     │    │  /api/auth/register      │   │
│  │  /register  │    │  /api/auth/login         │   │
│  │  /tasks     │    │  /api/auth/logout        │   │
│  └─────────────┘    │  /api/auth/me            │   │
│                     │  /api/tasks (GET, POST)  │   │
│  Middleware         │  /api/tasks/[id]         │   │
│  - JWT verify       │    (GET, PUT, DELETE)    │   │
│  - Route protect    └──────────────────────────┘   │
└─────────────────────────────────────────────────────┘
         │                         │
         ▼                         ▼
┌──────────────────┐    ┌─────────────────────┐
│  AES-256-GCM     │    │  MongoDB (Atlas)     │
│  Encrypt every   │    │  - users collection  │
│  req + response  │    │  - tasks collection  │
└──────────────────┘    └─────────────────────┘
```

### Security layers

1. **Transport** — HTTPS in production
2. **Payload encryption** — AES-256-GCM on every request/response body (client uses Web Crypto API, server uses Node.js `crypto`)
3. **Authentication** — JWT in HTTP-only cookie (not accessible from JS)
4. **Password storage** — bcrypt with 12 salt rounds
5. **Authorization** — every DB query scoped to `userId` from JWT
6. **Input sanitization** — Zod validation, regex special-char escaping for search
7. **Environment variables** — all secrets in `.env`, never hardcoded

---

## Setup

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (free tier works)

### 1. Clone & install

```bash
git clone https://github.com/your-username/taskapp.git
cd taskapp
npm install
```

### 2. Environment variables

Copy `.env.example` to `.env.local` and fill in:

```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/taskapp
JWT_SECRET=your-super-secret-jwt-key-min-32-chars
AES_SECRET_KEY=your-32-char-aes-key-for-encrypt
NEXT_PUBLIC_AES_SECRET_KEY=your-32-char-aes-key-for-encrypt
NODE_ENV=development
```

> Both `AES_SECRET_KEY` and `NEXT_PUBLIC_AES_SECRET_KEY` must be the same string so server and client can decrypt each other's payloads.

### 3. Run

```bash
npm run dev       # Development: http://localhost:3000
npm run build     # Production build
npm run start     # Start production server
```

---

## Deployment (Vercel)

```bash
npm i -g vercel
vercel --prod
```

Set all environment variables in the Vercel dashboard under Project → Settings → Environment Variables.

---

## API Documentation

All request bodies are AES-256-GCM encrypted (`{ data: "<encrypted_base64>" }`).  
All responses are AES-256-GCM encrypted. Decrypt with the shared AES key.

### Auth

#### POST /api/auth/register

**Encrypted request body:**
```json
{ "data": "<encrypted: {name, email, password}>" }
```

**Encrypted response (201):**
```json
{ "data": "<encrypted: {success: true, user: {id, name, email}}>" }
```
Sets `auth_token` HTTP-only cookie.

---

#### POST /api/auth/login

**Encrypted request body:**
```json
{ "data": "<encrypted: {email, password}>" }
```

**Encrypted response (200):**
```json
{ "data": "<encrypted: {success: true, user: {id, name, email}}>" }
```
Sets `auth_token` HTTP-only cookie.

---

#### POST /api/auth/logout

No body. Clears `auth_token` cookie.

---

### Tasks (all require auth cookie)

#### GET /api/tasks

**Query params:**
| Param | Type | Description |
|-------|------|-------------|
| page | number | Page number (default: 1) |
| limit | number | Items per page (default: 10, max: 50) |
| status | string | Filter: `pending`, `in-progress`, `completed` |
| search | string | Search by title (case-insensitive) |

**Encrypted response (200):**
```json
{
  "data": "<encrypted: {
    success: true,
    tasks: [{_id, title, description, status, userId, createdAt, updatedAt}],
    pagination: {total, page, limit, totalPages, hasNext, hasPrev}
  }>"
}
```

---

#### POST /api/tasks

**Encrypted request body:**
```json
{ "data": "<encrypted: {title, description?, status?}>" }
```

**Encrypted response (201):**
```json
{ "data": "<encrypted: {success: true, task: {...}}>" }
```

---

#### PUT /api/tasks/:id

**Encrypted request body:**
```json
{ "data": "<encrypted: {title?, description?, status?}>" }
```

**Encrypted response (200):**
```json
{ "data": "<encrypted: {success: true, task: {...}}>" }
```

---

#### DELETE /api/tasks/:id

No body.

**Encrypted response (200):**
```json
{ "data": "<encrypted: {success: true, message: 'Task deleted'}>" }
```

---

### Error responses

All errors are encrypted the same way:
```json
{ "data": "<encrypted: {success: false, error: 'Error message'}>" }
```

HTTP status codes: `400` (bad request), `401` (unauthorized), `404` (not found), `409` (conflict), `422` (validation), `500` (server error)

---

## Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── auth/
│   │   │   ├── register/route.ts
│   │   │   ├── login/route.ts
│   │   │   ├── logout/route.ts
│   │   │   └── me/route.ts
│   │   └── tasks/
│   │       ├── route.ts          # GET list, POST create
│   │       └── [id]/route.ts     # GET, PUT, DELETE by id
│   ├── login/page.tsx
│   ├── register/page.tsx
│   ├── tasks/page.tsx
│   ├── layout.tsx
│   ├── page.tsx                  # Redirects to /tasks
│   └── globals.css
├── components/
│   └── TaskModal.tsx
├── lib/
│   ├── apiClient.ts              # Client: encrypt requests, decrypt responses
│   ├── crypto.ts                 # Server: AES-256-GCM encrypt/decrypt
│   ├── db.ts                     # MongoDB connection
│   ├── jwt.ts                    # JWT sign/verify
│   └── response.ts               # Encrypted response helpers
├── middleware/
│   └── auth.ts                   # Extract user from JWT cookie
├── middleware.ts                 # Next.js route protection
└── models/
    ├── User.ts                   # Mongoose schema + bcrypt
    └── Task.ts                   # Mongoose schema + indexes
```
